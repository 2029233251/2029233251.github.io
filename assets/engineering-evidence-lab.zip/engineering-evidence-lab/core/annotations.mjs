export function validateAnnotations(rows){
  if(!Array.isArray(rows))throw Error('标注数据必须是数组');if(rows.length>10000)throw Error('最多10000条');
  const issues=[],seen=new Set(),videos=new Map();
  const add=(r,code,severity,message,index)=>issues.push({id:r?.id??`row-${index}`,code,severity,message});
  rows.forEach((r,i)=>{
    if(!r||typeof r!=='object'||Array.isArray(r)){add(r,'SCHEMA','critical','记录必须为对象',i);return;}
    if(typeof r.id!=='string'||!r.id||seen.has(r.id))add(r,'DUPLICATE_ID','critical','ID缺失或重复',i);seen.add(r.id);
    if(typeof r.video!=='string'||!r.video||typeof r.action!=='string'||!r.action||!['train','validation','test'].includes(r.split))add(r,'SCHEMA','critical','缺失video/action或split无效',i);
    if(!Number.isFinite(r.start)||!Number.isFinite(r.end)||r.start<0||r.end<=r.start)add(r,'TIMELINE','critical','时间需满足0≤start<end',i);
    if(!Number.isFinite(r.confidence)||r.confidence<0||r.confidence>1)add(r,'CONFIDENCE_RANGE','high','置信度必须在0到1',i);
    else if(r.confidence<.65)add(r,'LOW_CONFIDENCE','medium','置信度低于审核门槛0.65',i);
    if(!Array.isArray(r.objects)||!r.objects.length||r.objects.some(x=>typeof x!=='string'||!x.trim()))add(r,'MISSING_OBJECT','high','动作缺少有效交互对象',i);
    if(r.video){if(!videos.has(r.video))videos.set(r.video,[]);videos.get(r.video).push(r);}
  });
  for(const [video,group]of videos){const splits=new Set(group.map(r=>r.split));if(splits.size>1)for(const r of group)add(r,'SPLIT_LEAKAGE','critical',`${video}跨数据划分出现`,0);
    const segments=group.filter(r=>Number.isFinite(r.start)&&Number.isFinite(r.end)&&r.end>r.start).sort((a,b)=>a.start-b.start);
    for(let i=0;i<segments.length;i++)for(let j=i+1;j<segments.length&&segments[j].start<segments[i].end;j++){if(segments[i].lane===segments[j].lane){add(segments[j],'OVERLAP','high','同一视频/轨道的片段重叠',0);}}
  }
  const bad=new Set(issues.map(i=>i.id));
  return {records:rows.length,passRecords:rows.filter(r=>r&&typeof r==='object'&&typeof r.id==='string'&&r.id&&!bad.has(r.id)).length,issues,releaseAllowed:rows.length>0&&!issues.some(i=>['critical','high'].includes(i.severity)),scope:'时间重叠规则假设同轨单标签；不评估原视频视觉语义'};
}
export function compareVersions(before,after){const a=validateAnnotations(before),b=validateAnnotations(after);const counts=x=>x.issues.reduce((out,i)=>(out[i.code]=(out[i.code]||0)+1,out),{});return {before:a,after:b,issueDelta:b.issues.length-a.issues.length,beforeByCode:counts(a),afterByCode:counts(b)};}
export function agreement(a,b){
  const ids=x=>new Set(x.map(r=>r.id));if(ids(a).size!==a.length||ids(b).size!==b.length)throw Error('审核者数据ID必须唯一');
  const right=new Map(b.map(r=>[r.id,r.action]));const pairs=a.filter(r=>right.has(r.id)).map(r=>[r.action,right.get(r.id)]);if(!pairs.length)return {matched:0,agreement:null,kappa:null};
  const x=new Map(),y=new Map();let agree=0;for(const [p,q]of pairs){x.set(p,(x.get(p)||0)+1);y.set(q,(y.get(q)||0)+1);if(p===q)agree++;}
  const n=pairs.length,po=agree/n,pe=[...new Set([...x.keys(),...y.keys()])].reduce((s,k)=>s+(x.get(k)||0)*(y.get(k)||0)/(n*n),0);
  return {matched:n,agreement:po,kappa:Math.abs(1-pe)<1e-12?null:(po-pe)/(1-pe),scope:'按相同segment ID比对动作类别，不代表视觉语义正确率'};
}
