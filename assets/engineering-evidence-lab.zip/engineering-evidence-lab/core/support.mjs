// Offline, extractive baseline. No external model or customer data is used.
export function tokens(text) {
  const out=(String(text).toLowerCase().match(/[a-z0-9_]+/g)||[]);
  for(const run of String(text).match(/[\u4e00-\u9fff]+/g)||[]) {
    if(run.length===1)out.push(run);
    for(let i=0;i<run.length-1;i++)out.push(run.slice(i,i+2));
  }
  return out;
}
export class EvidenceIndex {
  constructor(documents) {
    if(!Array.isArray(documents)||!documents.length)throw Error('知识库不能为空');
    const ids=new Set();
    this.docs=documents.map(d=>{
      if(!d.id||ids.has(d.id)||!d.title||!d.body)throw Error('知识条目ID重复或字段缺失');
      ids.add(d.id);const ts=tokens(`${d.title} ${d.title} ${d.tags||''} ${d.body}`);
      const freq=new Map();for(const t of ts)freq.set(t,(freq.get(t)||0)+1);
      return {...d,freq,len:ts.length};
    });
    this.avg=this.docs.reduce((s,d)=>s+d.len,0)/this.docs.length;
    this.df=new Map();for(const d of this.docs)for(const t of d.freq.keys())this.df.set(t,(this.df.get(t)||0)+1);
  }
  search(query,k=3) {
    const terms=[...new Set(tokens(query))];
    return this.docs.map(d=>{
      let score=0;const matched=[];
      for(const t of terms){const f=d.freq.get(t)||0;if(!f)continue;
        const df=this.df.get(t)||0,idf=Math.log(1+(this.docs.length-df+.5)/(df+.5));
        score+=idf*(f*2.2)/(f+1.2*(.25+.75*d.len/this.avg));matched.push(t);
      }
      return {id:d.id,title:d.title,body:d.body,source:d.source,score,matched};
    }).filter(d=>d.score>0).sort((a,b)=>b.score-a.score||a.id.localeCompare(b.id)).slice(0,Math.max(0,k));
  }
}
export function buildAnswer(index,query,{minimumScore=1.5}={}) {
  const hits=index.search(query);
  if(!hits.length||hits[0].score<minimumScore)return {status:'abstain',answer:'证据不足，请补充产品名、错误码和脱敏复现步骤。',citations:[],hits};
  const top=hits[0];
  return {status:'evidence_found',answer:`排查建议（知识库摘录，非模型生成）：\n${top.body}\n[${top.id}]\n执行任何变更前需确认环境和权限；不自动修改系统。`,citations:[top.id],hits};
}
export function reviewReply(reply,documents) {
  const issues=[];const byId=new Map(documents.map(d=>[d.id,d]));
  const ids=[...String(reply).matchAll(/\[([A-Z]+-\d+)\]/g)].map(m=>m[1]);
  if(!ids.length)issues.push({code:'NO_CITATION',severity:'high',message:'回复缺少知识条目引用'});
  for(const id of ids)if(!byId.has(id))issues.push({code:'UNKNOWN_CITATION',severity:'high',message:`无法解析引用 ${id}`});
  if(/(?:保证|承诺|一定).{0,10}(?:退款|到账|修复|赔偿)|(?:退款|赔偿).{0,8}(?:24|48)小时/.test(reply))issues.push({code:'UNSUPPORTED_COMMITMENT',severity:'high',message:'包含无依据的结果或时限承诺，需人工确认'});
  if(/\b(?:AKIA[A-Z0-9]{16}|sk-[A-Za-z0-9_-]{12,})\b|[1-9]\d{16}[0-9Xx]/.test(reply))issues.push({code:'POSSIBLE_SECRET',severity:'critical',message:'疑似凭证或身份信息，禁止直接外发'});
  if(/(?:关闭|禁用).{0,8}(?:鉴权|身份验证|证书校验)|chmod\s+777|rm\s+-rf/.test(reply))issues.push({code:'RISKY_ACTION',severity:'critical',message:'高风险操作，不允许自动执行'});
  return {pass:!issues.length,issues,citations:[...new Set(ids)],scope:'规则校验，不证明语义正确或完整事实支持'};
}
