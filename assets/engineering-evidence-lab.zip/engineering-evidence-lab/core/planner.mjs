class Heap {
  constructor(){this.a=[];}
  push(x){let i=this.a.length;this.a.push(x);while(i){const p=(i-1)>>1;if(this.a[p].f<=x.f)break;this.a[i]=this.a[p];i=p;}this.a[i]=x;}
  pop(){if(!this.a.length)return null;const first=this.a[0],last=this.a.pop();if(this.a.length){let i=0;while(i*2+1<this.a.length){let c=i*2+1;if(c+1<this.a.length&&this.a[c+1].f<this.a[c].f)c++;if(this.a[c].f>=last.f)break;this.a[i]=this.a[c];i=c;}this.a[i]=last;}return first;}
  get size(){return this.a.length;}
}
export function validateGrid(grid){
  if(!Array.isArray(grid)||!grid.length||!Array.isArray(grid[0])||!grid[0].length)throw Error('地图不能为空');
  const width=grid[0].length;
  if(grid.length>100||width>100||grid.some(r=>r.length!==width||r.some(v=>!Number.isFinite(v)||v<0)))throw Error('地图必须为100×100以内的矩形；0为障碍，其他为正代价');
}
export function inflate(grid,radius=0){validateGrid(grid);if(!Number.isInteger(radius)||radius<0||radius>10)throw Error('半径必须为0至10整数');
  return grid.map((row,y)=>row.map((v,x)=>{if(!v)return 0;for(let dy=-radius;dy<=radius;dy++)for(let dx=-radius;dx<=radius;dx++)if(dx*dx+dy*dy<=radius*radius){const yy=y+dy,xx=x+dx;if(yy<0||xx<0||yy>=grid.length||xx>=row.length||grid[yy][xx]===0)return 0;}return v;}));
}
const key=([x,y])=>`${x},${y}`;
export function plan(grid,start,goal,{algorithm='astar',diagonal=false,radius=0}={}){
  validateGrid(grid);if(!['astar','dijkstra'].includes(algorithm))throw Error('不支持的算法');
  const safe=inflate(grid,radius),h=safe.length,w=safe[0].length;
  const valid=p=>Array.isArray(p)&&p.length===2&&p.every(Number.isInteger)&&p[0]>=0&&p[1]>=0&&p[0]<w&&p[1]<h;
  if(!valid(start)||!valid(goal))throw Error('起终点越界或不是整数坐标');
  if(!safe[start[1]][start[0]]||!safe[goal[1]][goal[0]])return {status:'blocked_endpoint',path:[],cost:null,expanded:0};
  const minimum=Math.min(...safe.flat().filter(v=>v>0));
  const heuristic=p=>{if(algorithm==='dijkstra')return 0;const dx=Math.abs(p[0]-goal[0]),dy=Math.abs(p[1]-goal[1]);return minimum*(diagonal?Math.max(dx,dy)+(Math.SQRT2-1)*Math.min(dx,dy):dx+dy);};
  const queue=new Heap(),distance=new Map([[key(start),0]]),parent=new Map();let expanded=0;
  queue.push({p:start,g:0,f:heuristic(start)});
  const dirs=[[1,0],[-1,0],[0,1],[0,-1],...(diagonal?[[1,1],[1,-1],[-1,1],[-1,-1]]:[])];
  while(queue.size){const node=queue.pop(),[x,y]=node.p,k=key(node.p);if(node.g!==distance.get(k))continue;expanded++;
    if(k===key(goal)){let p=goal,path=[p];while(key(p)!==key(start)){p=parent.get(key(p));path.push(p);}return {status:'ok',path:path.reverse(),cost:node.g,expanded};}
    for(const [dx,dy]of dirs){const nx=x+dx,ny=y+dy;if(nx<0||ny<0||nx>=w||ny>=h||!safe[ny][nx])continue;
      if(dx&&dy&&(!safe[y][nx]||!safe[ny][x]))continue;
      const p=[nx,ny],nk=key(p),g=node.g+safe[ny][nx]*(dx&&dy?Math.SQRT2:1);
      if(g<(distance.get(nk)??Infinity)){distance.set(nk,g);parent.set(nk,node.p);queue.push({p,g,f:g+heuristic(p)});}
    }
  }
  return {status:'unreachable',path:[],cost:null,expanded};
}
export function replan(grid,start,goal,obstacles,options={}){validateGrid(grid);const changed=grid.map(r=>r.slice());for(const p of obstacles){if(!Array.isArray(p)||p.length!==2||!p.every(Number.isInteger)||p[0]<0||p[1]<0||p[1]>=changed.length||p[0]>=changed[0].length)throw Error('动态障碍越界');changed[p[1]][p[0]]=0;}return {grid:changed,...plan(changed,start,goal,options)};}
export function seededMap(seed=42,size=24){let state=seed>>>0;const random=()=>((state=(1664525*state+1013904223)>>>0)/4294967296);const grid=Array.from({length:size},()=>Array.from({length:size},()=>random()<.2?0:random()<.12?4:1));for(let i=0;i<size;i++){grid[0][i]=1;grid[i][size-1]=1;}return grid;}
