import {EvidenceIndex, buildAnswer, reviewReply} from './core/support.mjs';
import {plan, replan, seededMap, inflate} from './core/planner.mjs';
import {validateAnnotations, compareVersions, agreement} from './core/annotations.mjs';
import {documents, beforeAnnotations, afterAnnotations} from './data/fixtures.mjs';

const $ = id => document.getElementById(id);
const esc = value => String(value).replace(/[&<>"']/g, char => ({'&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;'}[char]));
const index = new EvidenceIndex(documents);
let lastQuality = null, currentGrid = null, currentPlan = null;
let currentStart = [0, 0], currentGoal = [23, 23], obstacles = [], ready = false;
const tabs = [...document.querySelectorAll('[data-tab]')];
const copy = {
  support: {
    name: 'Evidence Desk', crumb: '01 / SUPPORT ENGINEERING',
    heading: '把答案，<em>连回证据。</em>',
    description: '以 BM25 检索、拒答阈值与规则审核，展示技术支持中可追溯的回答链路。'
  },
  robot: {
    name: 'Route Lab', crumb: '02 / ROBOTICS ENGINEERING',
    heading: '让每一步，<em>有据可循。</em>',
    description: 'A*、非均匀代价、安全半径与动态重规划。每条路径都能与 Dijkstra 基线对照。'
  },
  data: {
    name: 'Annotation Gate', crumb: '03 / DATA QUALITY ENGINEERING',
    heading: '在训练之前，<em>拦下问题。</em>',
    description: '从单条标注到版本发布：时间轴、置信度、轨道重叠与跨集合泄漏检查。'
  }
};
function announce(message) {
  if (ready) $('actionStatus').textContent = message;
}
function selectTool(tool, updateURL = true, focus = false) {
  if (!Object.hasOwn(copy, tool)) tool = 'support';
  const selected = copy[tool];
  for (const button of tabs) {
    const active = button.dataset.tab === tool;
    button.classList.toggle('active', active);
    button.setAttribute('aria-selected', String(active));
    button.tabIndex = active ? 0 : -1;
    if (active && focus) button.focus();
  }
  for (const panel of document.querySelectorAll('.panel')) panel.hidden = panel.id !== tool;
  $('crumb').textContent = selected.crumb;
  $('heading').innerHTML = selected.heading;
  $('subhead').textContent = selected.description;
  document.title = `${selected.name} · Engineering Evidence Lab · 赵成硕`;
  document.querySelector('meta[name="description"]').content = `${selected.description} 赵成硕个人工程原型；预置内容为自建模拟数据，计算在浏览器中完成。`;
  if (updateURL) {
    const url = new URL(window.location.href);
    url.searchParams.set('tool', tool);
    window.history.replaceState({tool}, '', url);
  }
  announce(`${selected.name} 已打开。${selected.description}`);
}
for (const button of tabs) {
  button.onclick = () => selectTool(button.dataset.tab);
  button.onkeydown = event => {
    let next;
    const position = tabs.indexOf(button);
    if (['ArrowRight', 'ArrowDown'].includes(event.key)) next = (position + 1) % tabs.length;
    if (['ArrowLeft', 'ArrowUp'].includes(event.key)) next = (position - 1 + tabs.length) % tabs.length;
    if (event.key === 'Home') next = 0;
    if (event.key === 'End') next = tabs.length - 1;
    if (next === undefined) return;
    event.preventDefault();
    selectTool(tabs[next].dataset.tab, true, true);
  };
}
window.addEventListener('popstate', () => selectTool(new URL(window.location.href).searchParams.get('tool'), false));
const mobile = window.matchMedia('(max-width:650px)');
const updateTabOrientation = () => document.querySelector('[role="tablist"]').setAttribute('aria-orientation', mobile.matches ? 'horizontal' : 'vertical');
mobile.addEventListener('change', updateTabOrientation);
updateTabOrientation();

$('retrieve').onclick = () => {
  const result = buildAnswer(index, $('query').value);
  $('answer').textContent = result.answer;
  $('hits').innerHTML = result.hits.length ? result.hits.map(hit => `<article class="hit"><h3>${esc(hit.title)} <span class="tag">${esc(hit.id)}</span></h3><div class="meta">SCORE ${hit.score.toFixed(3)} / ${esc(hit.source)}</div><p>${esc(hit.body)}</p><div class="meta">匹配词：${hit.matched.map(esc).join(' · ')}</div></article>`).join('') : '<div class="empty">没有可用证据，已触发拒答。</div>';
  announce(`检索完成，命中 ${result.hits.length} 条证据。${result.answer}`);
};
$('review').onclick = () => {
  const result = reviewReply($('reply').value, documents);
  $('reviewResult').innerHTML = result.pass ? '<p class="ok">规则检查通过；仍需人工核验语义与事实。</p>' : result.issues.map(issue => `<div class="risk"><b>${esc(issue.code)}</b> · ${esc(issue.message)}</div>`).join('');
  announce(result.pass ? '回复规则检查通过，仍需人工核验。' : `回复检查发现 ${result.issues.length} 项风险。${result.issues.map(issue => issue.message).join('；')}`);
};
function stat(value, label) {
  return `<div class="stat"><strong>${esc(value)}</strong><small>${esc(label)}</small></div>`;
}
function options() {
  return {diagonal: $('diagonal').checked, radius: Number($('radius').value)};
}
function draw() {
  const canvas = $('map'), ctx = canvas.getContext('2d'), n = currentGrid.length;
  const cell = canvas.width / n, safe = inflate(currentGrid, options().radius);
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  for (let y = 0; y < n; y++) for (let x = 0; x < n; x++) {
    ctx.fillStyle = currentGrid[y][x] === 0 ? '#2e2a24' : !safe[y][x] ? '#b6afa2' : currentGrid[y][x] > 1 ? '#c9b996' : '#f3f0e8';
    ctx.fillRect(x * cell, y * cell, cell - 1, cell - 1);
  }
  if (currentPlan.path.length) {
    ctx.strokeStyle = '#c74310'; ctx.lineWidth = cell * .22; ctx.beginPath();
    currentPlan.path.forEach(([x, y], i) => i ? ctx.lineTo((x + .5) * cell, (y + .5) * cell) : ctx.moveTo((x + .5) * cell, (y + .5) * cell));
    ctx.stroke();
  }
  for (const [x, y] of obstacles) {
    ctx.fillStyle = '#a73330'; ctx.fillRect(x * cell + 2, y * cell + 2, cell - 4, cell - 4);
  }
  for (const [point, color] of [[currentStart, '#177b5e'], [currentGoal, '#9b6018']]) {
    ctx.beginPath(); ctx.fillStyle = color;
    ctx.arc((point[0] + .5) * cell, (point[1] + .5) * cell, cell * .34, 0, 7); ctx.fill();
  }
  canvas.setAttribute('aria-label', `24 乘 24 栅格地图。起点 ${currentStart.join(',')}，终点 ${currentGoal.join(',')}；状态 ${currentPlan.status}；路径共 ${currentPlan.path.length} 个节点。橙线为路径，深色为障碍，红色为新增障碍。`);
}
function planningStats() {
  const oracle = plan(currentGrid, currentStart, currentGoal, {...options(), algorithm: 'dijkstra'});
  const matched = currentPlan.status === oracle.status && (currentPlan.cost === null || Math.abs(currentPlan.cost - oracle.cost) < 1e-8);
  $('planStats').innerHTML = stat(currentPlan.status, '规划状态') + stat(currentPlan.cost === null ? '—' : currentPlan.cost.toFixed(2), 'A* 路径代价') + stat(currentPlan.expanded, 'A* 展开节点') + stat(oracle.expanded, 'Dijkstra 展开节点') + stat(matched ? '一致' : '不一致', '基线代价 / 状态校验');
  draw();
  announce(`规划完成。状态 ${currentPlan.status}，路径代价 ${currentPlan.cost === null ? '无可行路径' : currentPlan.cost.toFixed(2)}，与 Dijkstra 基线${matched ? '一致' : '不一致'}。`);
}
$('plan').onclick = () => {
  try {
    const seed = Number($('seed').value);
    if (!Number.isInteger(seed) || seed < 1 || seed > 999999) throw Error('种子必须是 1 至 999999 的整数');
    currentGrid = seededMap(seed);
    currentStart = Number($('radius').value) ? [1, 1] : [0, 0];
    currentGoal = Number($('radius').value) ? [22, 22] : [23, 23];
    obstacles = [];
    currentPlan = plan(currentGrid, currentStart, currentGoal, options());
    planningStats();
  } catch (error) {
    $('planStats').textContent = error.message;
    announce(error.message);
  }
};
$('diagonal').onchange = $('radius').onchange = () => $('plan').click();
$('obstacle').onclick = () => {
  if (!currentPlan?.path || currentPlan.path.length < 5) {
    const message = '没有足够长的可行路径，无法注入中途障碍。';
    $('planStats').innerHTML += `<p class="bad">${message}</p>`;
    announce(message); return;
  }
  const originalPath = currentPlan.path;
  currentStart = originalPath[Math.floor(originalPath.length * .25)];
  const obstacle = originalPath[Math.floor(originalPath.length * .65)];
  obstacles.push(obstacle);
  const result = replan(currentGrid, currentStart, currentGoal, [obstacle], options());
  currentGrid = result.grid; currentPlan = result;
  planningStats();
};
function invalidateQuality() {
  lastQuality = null;
  if ($('exportPreview')) $('exportPreview').remove();
  $('qualityStats').textContent = '待重新检查';
  $('issues').textContent = '';
  $('versionCompare').textContent = '输入已变更，请重新运行质量闸门。';
}
function loadVersion() {
  $('annotations').value = JSON.stringify($('version').value === 'before' ? beforeAnnotations : afterAnnotations, null, 2);
  invalidateQuality();
}
$('annotations').oninput = invalidateQuality;
$('version').onchange = () => { loadVersion(); announce('标注版本已切换，请重新运行质量闸门。'); };
$('validate').onclick = () => {
  try {
    const input = JSON.parse($('annotations').value);
    const result = validateAnnotations(input), comparison = compareVersions(beforeAnnotations, input);
    lastQuality = {schemaVersion: '1.0', dataType: 'synthetic fixture / browser-edited input', generatedAt: new Date().toISOString(), input, result, comparison};
    $('qualityStats').innerHTML = stat(result.records, '标注条数') + stat(result.issues.length, '规则问题数') + stat(result.releaseAllowed ? '规则放行' : '阻止发布', '发布闸门');
    $('issues').innerHTML = result.issues.length ? result.issues.map(issue => `<div class="issue"><b>${esc(issue.severity.toUpperCase())} / ${esc(issue.code)} / ${esc(issue.id)}</b>${esc(issue.message)}</div>`).join('') : '<div class="empty">本次规则检查无问题。仍需人工视觉审核。</div>';
    let agreementText = '一致率不可计算（记录需为对象，并提供完整、唯一的 ID 与动作标签）';
    const validRows = input.every(row => row && typeof row === 'object' && !Array.isArray(row) && typeof row.id === 'string' && row.id.length > 0 && typeof row.action === 'string' && row.action.length > 0);
    const uniqueIDs = validRows && new Set(input.map(row => row.id)).size === input.length;
    if (uniqueIDs) {
      try {
        const pair = agreement(afterAnnotations, input);
        agreementText = pair.agreement === null ? '无可比 ID' : (pair.agreement * 100).toFixed(1) + '%';
      } catch {
        // Agreement is supplementary; schema findings and the export remain valid.
      }
    }
    $('versionCompare').textContent = `相对 V0 问题数变化：${comparison.issueDelta}。与演示参考动作标签一致率：${agreementText}（固定样本对照，非独立准确率）。`;
    announce(`质检完成，${result.records} 条标注发现 ${result.issues.length} 项规则问题。${result.releaseAllowed ? '规则放行，仍需人工视觉审核。' : '当前阻止发布。'}`);
  } catch (error) {
    lastQuality = null;
    if ($('exportPreview')) $('exportPreview').remove();
    $('qualityStats').textContent = '输入错误'; $('issues').textContent = error.message;
    $('versionCompare').textContent = '未生成可导出的结果。';
    announce(`输入错误：${error.message}`);
  }
};
$('export').onclick = () => {
  if (!lastQuality) {
    $('issues').textContent = '请先运行一次有效质检。';
    announce('请先运行一次有效质检。'); return;
  }
  const json = JSON.stringify(lastQuality, null, 2);
  let preview = $('exportPreview');
  if (!preview) {
    preview = document.createElement('textarea'); preview.id = 'exportPreview';
    preview.readOnly = true; preview.rows = 12;
    preview.setAttribute('aria-label', '本次证据 JSON；可复制内容或使用下载文件');
    $('export').after(preview);
  }
  preview.value = json;
  const url = URL.createObjectURL(new Blob([json], {type: 'application/json'}));
  const anchor = document.createElement('a');
  anchor.href = url; anchor.download = 'annotation-evidence.json';
  document.body.append(anchor); anchor.click(); anchor.remove();
  setTimeout(() => URL.revokeObjectURL(url), 10000);
  announce('已生成本次证据 JSON 并请求浏览器下载；也可复制下方文本。');
};
$('retrieve').click(); $('review').click(); $('plan').click(); loadVersion(); $('validate').click();
selectTool(new URL(window.location.href).searchParams.get('tool'));
ready = true;
