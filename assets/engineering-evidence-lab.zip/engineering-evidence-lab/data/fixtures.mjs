export const documents=[
 {id:'KB-101',title:'数据任务权限不足',tags:'DataWorks access denied permission 权限',body:'先记录任务ID、时间和脱敏错误码，检查执行身份与数据源授权是否一致；最小权限原则下复核权限范围，验证后重新运行。不要复制真实密钥。',source:'synthetic://support/access-v1'},
 {id:'KB-102',title:'模型服务限流429',tags:'PAI model endpoint rate limit 429 限流',body:'检查服务调用量与并发指标，区分限流和服务故障；客户端采用有上限的指数退避并加入抖动。扩容或调整配额需由有权限的人员确认。',source:'synthetic://support/rate-v1'},
 {id:'KB-103',title:'百炼模型回复质量与幻觉',tags:'百炼 Bailian hallucination 质量 引用',body:'收集脱敏问题和预期答案，核对检索证据与回复引用。证据不足时返回无法确认，检查样本覆盖和人工审核记录，不承诺模型回答始终准确。',source:'synthetic://support/quality-v1'},
 {id:'KB-104',title:'连接超时排查',tags:'network timeout DNS 网络 超时',body:'先区分DNS解析、网络连通、TLS握手和服务响应超时。记录各阶段耗时及脱敏日志，使用只读诊断；不要关闭证书校验或鉴权来修复连接。',source:'synthetic://support/network-v1'},
 {id:'KB-105',title:'工单反馈闭环',tags:'ticket 客户 反馈 跟进',body:'按用户场景、复现步骤、证据、影响范围和当前状态记录问题；修复结论需有验证记录。客户承诺、退款及补偿由授权人员确认。',source:'synthetic://support/ticket-v1'},
 {id:'KB-106',title:'API凭证泄漏应急',tags:'secret token 密钥 泄漏 凭证',body:'发现疑似密钥泄漏时停止传播原文，按组织流程通知授权负责人并进行凭证轮换。只保留脱敏证据，工具不得自动把密钥发送给外部模型。',source:'synthetic://support/secret-v1'}
];
export const retrievalCases=[['任务 access denied 权限不足','KB-101'],['模型接口429限流','KB-102'],['百炼回复幻觉怎么审核','KB-103'],['网络连接 timeout DNS','KB-104'],['客户工单反馈记录','KB-105'],['token 密钥泄漏','KB-106'],['PAI endpoint rate limit','KB-102'],['无法确认模型引用质量','KB-103']];
export const beforeAnnotations=[
 {id:'s1',video:'demo-a',start:0,end:3,action:'reach',objects:['cup'],confidence:.95,split:'train',lane:'robot'},
 {id:'s2',video:'demo-a',start:2.5,end:5,action:'grasp',objects:[],confidence:.52,split:'train',lane:'robot'},
 {id:'s3',video:'demo-a',start:5,end:8,action:'place',objects:['cup'],confidence:.91,split:'validation',lane:'robot'},
 {id:'s4',video:'demo-b',start:4,end:2,action:'release',objects:['block'],confidence:1.3,split:'validation',lane:'robot'}
];
export const afterAnnotations=[
 {id:'s1',video:'demo-a',start:0,end:3,action:'reach',objects:['cup'],confidence:.95,split:'train',lane:'robot'},
 {id:'s2',video:'demo-a',start:3,end:5,action:'grasp',objects:['cup'],confidence:.88,split:'train',lane:'robot'},
 {id:'s3',video:'demo-a',start:5,end:8,action:'place',objects:['cup'],confidence:.91,split:'train',lane:'robot'},
 {id:'s4',video:'demo-b',start:0,end:2,action:'release',objects:['block'],confidence:.93,split:'validation',lane:'robot'}
];
